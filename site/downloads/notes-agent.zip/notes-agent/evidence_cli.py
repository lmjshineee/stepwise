"""Chapter four: bounded multi-hop retrieval with explicit missing evidence."""
import argparse
import copy
import json
from pathlib import Path
from agent import Limits
from evidence import build_question, investigate
from replay_backend import Replay
from responses_backend import Responses, post_json

TASKS = [
    {"id": "checks", "question": "示例站点发布前要求检查什么？"},
    {"id": "rollback", "question": "如果链接检查失败，示例站点要求怎样恢复？"},
]


class EvidenceResponses(Responses):
    """Reuse the adapter while replacing the older prose-only answer contract."""
    def __init__(self, model, key, transport=post_json):
        def report_transport(payload, secret, timeout):
            instructions = ("只输出任务要求的 JSON 报告，不输出隐藏推理。\n"
                            + build_question(TASKS))
            return transport({**payload, "instructions": instructions,
                              "include": ["reasoning.encrypted_content"]}, secret, timeout)
        super().__init__(model, key, report_transport)


def fixture(case):
    here = Path(__file__).resolve().parent
    records = json.loads((here / "data/evidence_notes.json").read_text(encoding="utf-8"))
    turns = json.loads((here / "data/evidence_replay.json").read_text(encoding="utf-8"))
    report = json.loads(turns[-1][0]["content"][0]["text"])
    if case == "missing":
        records = [r for r in records if r["id"] != "rollback-policy"]
        # Search returns no recovery record, so omit the full read and report the gap.
        turns.pop(3)
        report["items"][1] = {"task_id": "rollback", "state": "missing",
                               "claim": "", "evidence": []}
    elif case == "wrong-claim":
        # A true quote can be attached to a false conclusion: a semantic counterexample.
        report["items"][1]["claim"] = "链接检查失败后直接上线，不必恢复。"
    turns[-1][0]["content"][0]["text"] = json.dumps(report, ensure_ascii=False)
    return records, turns


def main():
    parser = argparse.ArgumentParser(description="逐项核对公开示例资料")
    parser.add_argument("--case", choices=["full", "missing", "wrong-claim"], default="full")
    parser.add_argument("--live", action="store_true")
    parser.add_argument("--show-report", action="store_true")
    parser.add_argument("--calls", type=int, default=6)
    args = parser.parse_args()
    if args.live and args.case == "wrong-claim":
        parser.error("wrong-claim 是离线语义反例，不能与 --live 同用")
    try:
        records, turns = fixture(args.case)
        backend = EvidenceResponses.from_env() if args.live else Replay(copy.deepcopy(turns))
        result, audit = investigate(backend, records, TASKS, Limits(calls=args.calls))
    except (ValueError, OSError):
        print("配置或公开样例加载失败。")
        return 2
    print("mode:", "live" if args.live else "protocol-replay")
    print("audit:", audit.status)
    print(f"covered: {audit.covered}/{len(TASKS)}")
    print("missing:", ",".join(audit.missing) or "none")
    print(f"turns: {result.turns}, calls: {result.calls}")
    for issue in audit.issues:
        print("issue:", issue["code"])
    if args.show_report and audit.status in {"needs_review", "evidence_gap"}:
        # Explicit terminal preview; JSON escaping keeps control characters quoted.
        print(json.dumps(json.loads(result.answer), ensure_ascii=False, indent=2))
    # Report only metadata by default; never write model output to a trace.
    return 0 if audit.status == "needs_review" else 1


if __name__ == "__main__":
    raise SystemExit(main())
