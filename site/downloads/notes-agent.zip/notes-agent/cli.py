import argparse
import json
from pathlib import Path
from agent import Limits, run
from replay_backend import Replay
from responses_backend import Responses
from tools import Notes


def main():
    parser = argparse.ArgumentParser(description="公开资料问答 Agent")
    parser.add_argument("question")
    parser.add_argument("--live", action="store_true")
    parser.add_argument("--turns", type=int, default=6)
    parser.add_argument("--calls", type=int, default=6)
    parser.add_argument("--trace", type=Path)
    args = parser.parse_args()
    here = Path(__file__).resolve().parent
    try:
        limits = Limits(turns=args.turns, calls=args.calls)
        backend = (Responses.from_env() if args.live
                   else Replay.load(here / "data/replay.json"))
        result = run(backend, Notes.load(here / "data/notes.json"), args.question, limits)
        if args.trace:
            # Trace is local opt-in; never raw prompts, documents or credentials.
            args.trace.write_text("".join(json.dumps(e, ensure_ascii=False) + "\n"
                                          for e in result.events), encoding="utf-8")
    except (ValueError, OSError):
        print("配置、资料或轨迹写入失败；检查环境变量、预算与文件权限。")
        return 2
    print("mode:", "live" if args.live else "protocol-replay")
    print("status:", result.status)
    if result.answer:
        print(result.answer)
    print(f"turns: {result.turns}, calls: {result.calls}")
    return 0 if result.status == "complete" else 1


if __name__ == "__main__":
    raise SystemExit(main())
