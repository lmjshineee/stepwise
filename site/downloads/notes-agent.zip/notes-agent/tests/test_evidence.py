import copy
import json
import unittest
from agent import Limits
from evidence import ReadLedger, audit_report, build_question, investigate
from evidence_cli import EvidenceResponses, TASKS, fixture
from replay_backend import Replay
from tools import ToolError
from responses_backend import INSTRUCTIONS, Responses


class EvidenceTests(unittest.TestCase):
    def setUp(self):
        self.records, self.turns = fixture("full")
        self.report = json.loads(self.turns[-1][0]["content"][0]["text"])
        self.reads = {r["id"]: r for r in self.records}

    def audit(self, report=None, reads=None):
        return audit_report(json.dumps(self.report if report is None else report,
                                       ensure_ascii=False), TASKS,
                            self.reads if reads is None else reads)

    def test_two_hop_replay_and_original_gate_are_separate(self):
        result, audit = investigate(Replay(self.turns), self.records, TASKS)
        self.assertEqual((result.turns, result.calls), (5, 4))
        self.assertEqual(result.status, "unverified_answer")
        self.assertEqual((audit.status, audit.covered), ("needs_review", 2))

    def test_next_search_uses_observed_recovery_hint(self):
        owner, scripted = self, Replay(self.turns)
        class Inspect:
            def generate(self, messages, tools):
                if scripted.index == 2:
                    observation = json.loads(messages[-1]["output"])
                    owner.assertIn("恢复约定", observation["data"]["text"])
                if scripted.index == 4:
                    owner.assertEqual(json.loads(messages[-1]["output"])["data"]["id"],
                                      "rollback-policy")
                return scripted.generate(messages, tools)
        _, audit = investigate(Inspect(), self.records, TASKS)
        self.assertEqual(audit.status, "needs_review")

    def test_missing_record_is_a_gap_not_task_completion(self):
        records, turns = fixture("missing")
        result, audit = investigate(Replay(turns), records, TASKS)
        self.assertEqual((result.turns, result.calls), (4, 3))
        self.assertEqual((audit.status, audit.covered, audit.missing),
                         ("evidence_gap", 1, ["rollback"]))

    def test_search_summary_and_failed_read_do_not_enter_ledger(self):
        notes = ReadLedger(self.records)
        self.assertTrue(notes.execute("search_notes", {"query": "发布"}))
        with self.assertRaises(ToolError):
            notes.execute("read_note", {"id": "absent"})
        self.assertEqual(notes.reads, {})
        note = notes.execute("read_note", {"id": "release-policy"})
        note["text"] = "caller mutation"
        self.assertEqual(notes.reads["release-policy"]["text"], self.records[0]["text"])
        audit = self.audit(reads={})
        self.assertEqual(audit.status, "invalid_report")
        self.assertEqual({i["code"] for i in audit.issues}, {"unread_note"})

    def test_omission_duplicate_and_unknown_tasks_are_rejected(self):
        malformed = [self.report["items"][:1], [self.report["items"][0]] * 2,
                     [dict(self.report["items"][0], task_id="invented"), self.report["items"][1]]]
        for items in malformed:
            with self.subTest(items=items):
                self.assertEqual(self.audit({"items": items}).status, "invalid_report")

    def test_quote_edit_and_unread_record_are_rejected(self):
        for changes, code in [({"quote": "构建通过即可直接上线。"}, "quote_mismatch"),
                              ({"note_id": "absent"}, "unread_note")]:
            report = copy.deepcopy(self.report)
            report["items"][1]["evidence"][0].update(changes)
            audit = self.audit(report)
            self.assertEqual(audit.status, "invalid_report")
            self.assertEqual(audit.issues[0]["code"], code)

    def test_shapes_and_empty_support_fail_closed(self):
        for change in [{"state": []}, {"claim": ""}, {"evidence": []},
                       {"state": "missing"}, {"evidence": [{"note_id": [], "quote": "x"}]},
                       {"evidence": [{"note_id": "release-policy", "quote": " "}]}]:
            report = copy.deepcopy(self.report)
            report["items"][0].update(change)
            self.assertEqual(self.audit(report).status, "invalid_report")
        for text in ['{"items":[],"items":[]}', "```json\n{}\n```", "x" * 16001,
                     '[' * 2000, '{}', 'null']:
            self.assertEqual(audit_report(text, TASKS, self.reads).status, "invalid_report")

    def test_correct_quote_does_not_establish_semantic_support(self):
        records, turns = fixture("wrong-claim")
        self.assertIn("直接上线", turns[-1][0]["content"][0]["text"])
        _, audit = investigate(Replay(turns), records, TASKS)
        self.assertEqual(audit.status, "needs_review")

    def test_budget_stop_cannot_be_relabelled_as_evidence_success(self):
        result, audit = investigate(Replay(self.turns), self.records, TASKS, Limits(calls=3))
        self.assertEqual((result.status, result.calls), ("call_limit", 3))
        self.assertEqual((audit.status, audit.covered), ("run_stopped", 0))
        self.assertEqual(audit.issues, [{"code": "call_limit"}])

    def test_ledger_does_not_leak_into_next_run(self):
        investigate(Replay(self.turns), self.records, TASKS)
        _, audit = investigate(Replay([self.turns[-1]]), self.records, TASKS)
        self.assertEqual(audit.status, "invalid_report")
        self.assertEqual({i["code"] for i in audit.issues}, {"unread_note"})

    def test_invalid_task_contracts_are_rejected_before_backend_call(self):
        for tasks in [[], TASKS * 2, [{"id": "bad id", "question": "q"}],
                      [{"id": "ok", "question": " "}], [{"id": [], "question": "q"}]]:
            with self.assertRaises(ValueError):
                build_question(tasks)


    def test_live_contract_replaces_prose_instructions_without_changing_old_adapter(self):
        payloads = []
        def transport(payload, key, timeout):
            payloads.append(payload)
            self.assertEqual((key, timeout), ("fixture-key", 30))
            return {"status": "completed", "output": self.turns[-1]}
        backend = EvidenceResponses("fixture-model", "fixture-key", transport)
        self.assertEqual(backend.generate([], []), self.turns[-1])
        backend.generate([], [])
        self.assertIn('"rollback"', payloads[0]["instructions"])
        self.assertIn("JSON", payloads[0]["instructions"])
        self.assertNotIn("[资料ID]", payloads[0]["instructions"])
        self.assertEqual(payloads[0]["instructions"], payloads[1]["instructions"])
        self.assertEqual(payloads[0]["include"], ["reasoning.encrypted_content"])
        Responses("fixture-model", "fixture-key", transport).generate([], [])
        self.assertEqual(payloads[2]["instructions"], INSTRUCTIONS)
        self.assertNotIn("include", payloads[2])


if __name__ == "__main__":
    unittest.main()
