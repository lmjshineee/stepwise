import copy
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import urllib.error
from agent import Limits, ModelError, run
from tools import Notes, SPECS, ToolError
from replay_backend import Replay
from responses_backend import Responses, post_json
import loop_demo

ROOT = Path(__file__).resolve().parents[1]


def call(name="read_note", args=None, ident="c1"):
    return {"type": "function_call", "call_id": ident, "name": name,
            "arguments": json.dumps(args if args is not None else {"id": "release"})}


def answer(text="还要检查输入边界和部署路径。[release]"):
    return {"type": "message", "role": "assistant",
            "content": [{"type": "output_text", "text": text}]}


class AgentTests(unittest.TestCase):
    def setUp(self):
        self.notes = Notes.load(ROOT / "data/notes.json")

    def test_end_to_end_replay(self):
        result = run(Replay.load(ROOT / "data/replay.json"), self.notes, "发布检查")
        self.assertEqual((result.status, result.turns, result.calls), ("complete", 3, 2))
        self.assertIn("[release]", result.answer)

    def test_tool_result_reaches_next_model_call(self):
        owner = self
        class Inspect:
            turns = 0
            def generate(self, messages, tools):
                self.turns += 1
                if self.turns == 1:
                    return [call()]
                owner.assertEqual(messages[-2]["call_id"], messages[-1]["call_id"])
                data = json.loads(messages[-1]["output"])
                owner.assertEqual(data["data"]["id"], "release")
                owner.assertTrue(data["ok"])
                return [answer()]
        self.assertEqual(run(Inspect(), self.notes, "question").status, "complete")

    def test_reasoning_state_is_preserved(self):
        owner = self
        opaque = {"type": "reasoning", "encrypted_content": "opaque-test", "summary": []}
        class Inspect:
            turns = 0
            def generate(self, messages, tools):
                self.turns += 1
                if self.turns == 1:
                    return [opaque, call()]
                owner.assertEqual(messages[1], opaque)
                return [answer()]
        self.assertEqual(run(Inspect(), self.notes, "question").status, "complete")

    def test_tool_error_can_be_corrected(self):
        turns = [[call(args={"id": "missing"})],
                 [call(ident="c2")], [answer()]]
        result = run(Replay(turns), self.notes, "question")
        self.assertEqual(result.status, "complete")
        self.assertEqual([e["ok"] for e in result.events[:-1]], [False, True])

    def test_invalid_arguments_do_not_execute(self):
        for args in ({"id": 1}, {"id": "release", "path": "/tmp/x"}, [],
                     {"id": " "}, {"id": "x" * 121}):
            with self.subTest(args=args):
                with self.assertRaises(ToolError):
                    self.notes.execute("read_note", args)

    def test_malformed_json_returns_observation(self):
        owner = self
        bad = call(); bad["arguments"] = "{"
        class Inspect:
            turns = 0
            def generate(self, messages, tools):
                self.turns += 1
                if self.turns == 1:
                    return [bad]
                owner.assertEqual(json.loads(messages[-1]["output"]),
                                  {"ok": False, "error": "invalid_json"})
                return [answer()]
        result = run(Inspect(), self.notes, "question")
        self.assertEqual(result.status, "unverified_answer")

    def test_tool_budget_is_checked_before_batch_execution(self):
        with patch.object(self.notes, "execute", wraps=self.notes.execute) as execute:
            result = run(Replay([[call(), call(ident="c2")]]), self.notes,
                         "question", Limits(calls=1))
            self.assertEqual((result.status, result.calls), ("call_limit", 0))
            execute.assert_not_called()

    def test_turn_limit_stops_repeated_searches(self):
        turns = [[call("search_notes", {"query": "missing"}, f"c{i}")]
                 for i in range(3)]
        result = run(Replay(turns), self.notes, "question", Limits(turns=2))
        self.assertEqual((result.status, result.turns, result.calls), ("turn_limit", 2, 2))

    def test_context_limit_prevents_model_request(self):
        backend = Replay([[answer()]])
        result = run(backend, self.notes, "x" * 200, Limits(context_chars=50))
        self.assertEqual((result.status, backend.index), ("context_limit", 0))

    def test_duplicate_call_id_is_protocol_error(self):
        result = run(Replay([[call()], [call()]]), self.notes, "question")
        self.assertEqual((result.status, result.calls), ("protocol_error", 1))

    def test_call_id_collision_within_batch_is_not_executed(self):
        result = run(Replay([[call(), call()]]), self.notes, "question")
        self.assertEqual((result.status, result.calls), ("protocol_error", 0))

    def test_unread_or_malformed_citations_are_not_accepted(self):
        for text in ("没有来源", "[missing]", "[release] [unknown_id]"):
            result = run(Replay([[call()], [answer(text)]]), self.notes, "question")
            self.assertEqual(result.status, "unverified_answer")
        result = run(Replay([[answer()]]), self.notes, "question")
        self.assertEqual(result.status, "unverified_answer")

    def test_valid_citation_does_not_prove_truth(self):
        result = run(Replay([[call()], [answer("构建通过就保证没有缺陷。[release]")]]),
                     self.notes, "question")
        self.assertEqual(result.status, "complete")  # Deliberate semantic counterexample.

    def test_untrusted_text_cannot_add_shell_tool(self):
        turns = [[call(args={"id": "untrusted"})],
                 [call("shell", {"command": "echo forbidden"}, "c2")],
                 [answer("这条资料包含越权要求。[untrusted]")]]
        with patch("subprocess.run") as process:
            result = run(Replay(turns), self.notes, "question")
            process.assert_not_called()
        self.assertEqual(result.status, "complete")
        self.assertEqual(result.events[1]["tool"], "unknown")
        self.assertFalse(result.events[1]["ok"])

    def test_trace_has_only_metadata(self):
        question = "do-not-log-question"
        result = run(Replay.load(ROOT / "data/replay.json"), self.notes, question)
        text = json.dumps(result.events, ensure_ascii=False)
        self.assertNotIn(question, text)
        for record in self.notes.records.values():
            self.assertNotIn(record["text"], text)
        self.assertNotIn("arguments", text)

    def test_protocol_shape_and_refusal(self):
        for output in ([], None, [1], [{"type": "web_search_call"}],
                       [{"type": "message", "content": 123}]):
            self.assertEqual(run(Replay([output]), self.notes, "q").status, "protocol_error")
        refusal = {"type": "message", "content": [{"type": "refusal", "refusal": "no"}]}
        self.assertEqual(run(Replay([[refusal]]), self.notes, "q").status, "refused")

    def test_repeated_runs_do_not_change_notes_or_specs(self):
        before = copy.deepcopy((self.notes.records, SPECS))
        for _ in range(2):
            run(Replay.load(ROOT / "data/replay.json"), self.notes, "q")
        self.assertEqual(before, (self.notes.records, SPECS))

    def test_search_empty_and_read_copy(self):
        self.assertEqual(self.notes.execute("search_notes", {"query": "not-present"}), [])
        found = self.notes.execute("search_notes", {"query": "发布"})
        self.assertEqual(found[0]["id"], "release")
        copy_record = self.notes.execute("read_note", {"id": "release"})
        copy_record["text"] = "changed"
        self.assertNotEqual(self.notes.records["release"]["text"], "changed")

    def test_loop_demo_rejects_missing_or_wrong_observation(self):
        with self.assertRaises(ValueError):
            loop_demo.replay([{}, {}])
        with self.assertRaises(ValueError):
            loop_demo.replay([{}, {"type": "function_call_output", "call_id": "wrong"}])

    def test_limits_reject_nonpositive_or_boolean(self):
        for value in (0, -1, True):
            with self.assertRaises(ValueError):
                Limits(turns=value)


class AdapterTests(unittest.TestCase):
    def test_response_payload_and_output(self):
        captured = []
        def transport(payload, key, timeout):
            captured.append((payload, key, timeout))
            return {"status": "completed", "output": [call()]}
        backend = Responses("model-under-test", "test-only-not-a-key", transport)
        output = backend.generate([{"role": "user", "content": "q"}], SPECS)
        self.assertEqual(output[0]["call_id"], "c1")
        payload, key, timeout = captured[0]
        self.assertFalse(payload["store"])
        self.assertFalse(payload["parallel_tool_calls"])
        self.assertEqual(payload["max_output_tokens"], 2048)
        self.assertEqual(timeout, 30)
        self.assertNotIn("Authorization", payload)

    def test_incomplete_and_bad_response_stop(self):
        for response in ({"status": "incomplete", "output": [answer()]}, [], None):
            backend = Responses("test", "test", lambda *args: response)
            self.assertIn(run(backend, Notes([]), "q").status,
                          {"response_not_completed", "response_shape_error"})

    def test_no_credentials_is_configuration_error(self):
        with self.assertRaises(ValueError):
            Responses("", "")

    def test_network_error_does_not_leak_exception_text(self):
        opener = unittest.mock.Mock()
        opener.open.side_effect = urllib.error.URLError("private-token-value")
        with patch("urllib.request.build_opener", return_value=opener):
            with self.assertRaisesRegex(ModelError, "^network_error$"):
                post_json({}, "test-only", 1)

    def test_http_error_does_not_include_response_body(self):
        import io
        opener = unittest.mock.Mock()
        opener.open.side_effect = urllib.error.HTTPError(
            "https://api.openai.com/v1/responses", 401, "private", {},
            io.BytesIO(b"private-token-value"))
        with patch("urllib.request.build_opener", return_value=opener):
            with self.assertRaisesRegex(ModelError, "^http_401$"):
                post_json({}, "test-only", 1)


if __name__ == "__main__":
    unittest.main()
