"""A bounded host loop. Backends return Responses-compatible output items."""
import copy
import json
import re
from dataclasses import dataclass, field
from tools import Notes, SPECS, ToolError


class ModelError(RuntimeError):
    """Only a public error code, never HTTP bodies or credentials."""


@dataclass(frozen=True)
class Limits:
    turns: int = 6
    calls: int = 6
    context_chars: int = 24000

    def __post_init__(self):
        if any(type(n) is not int or n <= 0
               for n in (self.turns, self.calls, self.context_chars)):
            raise ValueError("limits must be positive integers")


@dataclass
class Result:
    status: str
    answer: str = ""
    turns: int = 0
    calls: int = 0
    events: list = field(default_factory=list)


def run(backend, notes: Notes, question: str, limits=Limits()):
    messages = [{"role": "user", "content": question}]
    result = Result("turn_limit")
    seen_ids, read_ids = set(), set()
    for turn in range(1, limits.turns + 1):
        if len(json.dumps(messages, ensure_ascii=False)) > limits.context_chars:
            result.status = "context_limit"
            break
        result.turns = turn
        try:
            output = backend.generate(copy.deepcopy(messages), copy.deepcopy(SPECS))
        except ModelError as error:
            result.status = str(error)
            break
        if (not isinstance(output, list) or not output or len(output) > 32
                or any(not isinstance(x, dict)
                       or x.get("type") not in {"message", "function_call", "reasoning"}
                       for x in output)
                or any(x["type"] == "message"
                       and (not isinstance(x.get("content"), list)
                            or any(not isinstance(p, dict) for p in x["content"]))
                       for x in output)):
            result.status = "protocol_error"
            break
        # Preserve all output items, including opaque reasoning state.
        messages.extend(copy.deepcopy(output))
        calls = [x for x in output if x["type"] == "function_call"]
        if not calls:
            content = [part for x in output if x["type"] == "message"
                       for part in x.get("content", []) if isinstance(part, dict)]
            result.answer = "".join(x.get("text", "") for x in content
                                    if x.get("type") == "output_text"
                                    and isinstance(x.get("text"), str))
            if any(x.get("type") == "refusal" for x in content):
                result.status = "refused"
            else:
                cited = set(re.findall(r"\[([^\[\]\n]+)\]", result.answer))
                result.status = ("complete" if cited and cited <= read_ids
                                 else "unverified_answer")
            break
        if result.calls + len(calls) > limits.calls:
            result.status = "call_limit"
            break
        ids = [c.get("call_id") for c in calls]
        if (any(not isinstance(i, str) or not 1 <= len(i) <= 120 for i in ids)
                or len(set(ids)) != len(ids) or seen_ids.intersection(ids)
                or any(not isinstance(c.get("name"), str)
                       or not isinstance(c.get("arguments"), str) for c in calls)):
            result.status = "protocol_error"
            break
        seen_ids.update(ids)
        for call in calls:
            result.calls += 1
            try:
                if len(call["arguments"]) > 8192:
                    raise ToolError("arguments_too_large")
                args = json.loads(call["arguments"])
                data = notes.execute(call["name"], args)
                observation = {"ok": True, "data": data}
                if call["name"] == "read_note":
                    read_ids.add(data["id"])
            except (json.JSONDecodeError, RecursionError):
                observation = {"ok": False, "error": "invalid_json"}
            except ToolError as error:
                observation = {"ok": False, "error": str(error)}
            safe_name = call["name"] if call["name"] in {
                "search_notes", "read_note"} else "unknown"
            result.events.append({"turn": turn, "call_id": call["call_id"],
                                  "tool": safe_name, "ok": observation["ok"]})
            messages.append({"type": "function_call_output",
                             "call_id": call["call_id"],
                             "output": json.dumps(observation, ensure_ascii=False)})
    result.events.append({"event": "stop", "status": result.status,
                          "turns": result.turns, "calls": result.calls})
    return result
