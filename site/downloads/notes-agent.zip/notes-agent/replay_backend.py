"""Fixed responses for checking the host; no network and no model decisions."""
import copy
import json
from agent import ModelError


class Replay:
    def __init__(self, turns):
        self.turns = copy.deepcopy(turns)
        self.index = 0

    @classmethod
    def load(cls, filename):
        with open(filename, encoding="utf-8") as source:
            return cls(json.load(source))

    def generate(self, messages, tools):
        if self.index >= len(self.turns):
            raise ModelError("replay_exhausted")
        output = self.turns[self.index]
        self.index += 1
        return copy.deepcopy(output)
