"""Chapter 1: a protocol replay, not a model that chooses actions."""
import json


def replay(messages):
    if len(messages) == 1:
        return [{"type": "function_call", "call_id": "c1",
                 "name": "read_note", "arguments": '{"id":"release"}'}]
    observation = messages[-1]
    if observation.get("type") != "function_call_output":
        raise ValueError("missing tool observation")
    if observation.get("call_id") != "c1":
        raise ValueError("tool observation belongs to another call")
    record = json.loads(observation["output"])
    return [{"type": "message", "role": "assistant", "content": [
        {"type": "output_text", "text": record["text"] + " [release]"}]}]


def run(choose, question):
    messages = [{"role": "user", "content": question}]
    notes = {"release": "构建通过后，还要运行边界测试。"}
    for turn in range(1, 4):
        output = choose(messages)
        messages.extend(output)
        calls = [item for item in output if item["type"] == "function_call"]
        if not calls:
            return "".join(part["text"] for item in output
                           if item["type"] == "message"
                           for part in item["content"]
                           if part["type"] == "output_text")
        for call in calls:
            if call["name"] != "read_note":
                raise ValueError("tool not allowed")
            args = json.loads(call["arguments"])
            if set(args) != {"id"} or args["id"] not in notes:
                raise ValueError("invalid note id")
            result = {"id": args["id"], "text": notes[args["id"]]}
            print(f"turn {turn}: read_note -> {result['id']}")
            messages.append({"type": "function_call_output",
                             "call_id": call["call_id"],
                             "output": json.dumps(result, ensure_ascii=False)})
    raise RuntimeError("turn limit reached")


if __name__ == "__main__":
    print(run(replay, "构建通过就能发布吗？"))
