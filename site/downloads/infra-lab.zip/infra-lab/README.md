# Stepwise Infra Lab

The mathematics and Python lessons share this small, offline CPU project. It is
not a model server. Async waiting jobs are fixtures; CPU timings are real local
batch-call measurements and do not establish GPU performance or serving P99.

Python 3.12+ is required. From this directory:

```sh
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements-verified.txt
python -m unittest discover -s tests -v
python -m infra_lab.linear
python -m infra_lab.low_rank
python -m infra_lab.calculus
python -m infra_lab.backward
python -m infra_lab.probability
python -m infra_lab.distributions
python -m infra_lab.convex
python -m infra_lab.numerics
python -m infra_lab.basics
python -m infra_lab.tensors
python -m infra_lab.pipeline
python -m infra_lab.concurrency
python -m infra_lab.concurrency --cpu
python -m infra_lab.measure
```

Windows PowerShell activation: `.venv\Scripts\Activate.ps1`.
`requirements-verified.txt` records the delivered versions, not all platform
support. Dependency installation needs network access; all experiments then run
offline. Broader compatible ranges live in `pyproject.toml`.

Use the printed interpreter/environment information with any report. The tests
check contracts, analytic results, numerical references, actual PyTorch gradients,
storage sharing, boundary inputs, bounded queues, cancellation and error cleanup.
They do not assert that an implementation is faster on your machine. The CPU
process comparison actually uses spawn and checks equal results.

The public JSONL sample is synthetic. Do not add private logs, tokens, credentials,
or personal workloads to a copy intended for sharing. Importing a module does not
start work; command entry points are guarded by `if __name__ == "__main__"`.
