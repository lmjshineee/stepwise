"""Truncated SVD is an approximation, not a LoRA training procedure."""
import numpy as np


def approximate(matrix, rank):
    matrix = np.asarray(matrix, dtype=np.float64)
    if matrix.ndim != 2 or not all(matrix.shape) or not np.isfinite(matrix).all():
        raise ValueError("expected a nonempty finite matrix")
    if type(rank) is not int or not 0 <= rank <= min(matrix.shape):
        raise ValueError("rank outside matrix dimensions")
    u, singular, vh = np.linalg.svd(matrix, full_matrices=False)
    return (u[:, :rank] * singular[:rank]) @ vh[:rank], singular


def main():
    matrix = np.diag([4., 1.])
    rebuilt, singular = approximate(matrix, 1)
    print("singular:", singular.tolist())
    print("rank-one reconstruction:", rebuilt.tolist())
    print("Frobenius error:", float(np.linalg.norm(matrix - rebuilt)))
    rows, columns, rank = 64, 64, 4
    print("dense/factored parameters:", rows * columns, rank * (rows + columns))


if __name__ == "__main__":
    main()
