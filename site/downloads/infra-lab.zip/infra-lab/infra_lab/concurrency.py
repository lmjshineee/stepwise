"""Bounded async scheduling for waiting jobs; separate real CPU executors."""
import asyncio
from concurrent.futures import ThreadPoolExecutor, ProcessPoolExecutor
import math
import multiprocessing
import time


async def run_jobs(delays, concurrency=2, capacity=2, timeout=1., fail_at=None):
    delays = list(delays)
    if any(type(n) is not int or n < 1 for n in (concurrency, capacity)):
        raise ValueError("positive worker and queue limits required")
    if not math.isfinite(timeout) or timeout <= 0 or any(not math.isfinite(x) or x < 0 for x in delays):
        raise ValueError("finite nonnegative delays and positive timeout required")
    queue = asyncio.Queue(maxsize=capacity)
    active, peak, queued_peak = 0, 0, 0
    completed, events = [], []
    start = time.perf_counter()

    async def produce():
        nonlocal queued_peak
        for number, delay in enumerate(delays):
            await queue.put((number, delay))
            queued_peak = max(queued_peak, queue.qsize())
        for _ in range(concurrency):
            await queue.put(None)

    async def work():
        nonlocal active, peak
        while True:
            item = await queue.get()
            try:
                if item is None:
                    return
                number, delay = item
                active += 1
                peak = max(peak, active)
                events.append({"job": number, "state": "start", "seconds": time.perf_counter() - start})
                try:
                    await asyncio.sleep(delay)  # Waiting fixture, not model inference.
                    if number == fail_at:
                        raise RuntimeError("deliberate job failure")
                    completed.append(number)
                    events.append({"job": number, "state": "end", "seconds": time.perf_counter() - start})
                finally:
                    active -= 1
            finally:
                queue.task_done()

    async with asyncio.timeout(timeout):
        async with asyncio.TaskGroup() as group:
            for _ in range(concurrency):
                group.create_task(work())
            group.create_task(produce())
    return {"completed": sorted(completed), "peak_active": peak, "peak_queued": queued_peak,
            "active_at_end": active, "events": events, "elapsed_seconds": time.perf_counter() - start}


def cpu_job(values):
    return math.fsum(x*x for x in values)


def cpu_executors():
    chunks = [list(range(1000)), list(range(500, 1500))]
    sequential = list(map(cpu_job, chunks))
    with ThreadPoolExecutor(max_workers=2) as executor:
        threaded = list(executor.map(cpu_job, chunks))
    with ProcessPoolExecutor(max_workers=2, mp_context=multiprocessing.get_context("spawn")) as executor:
        processed = list(executor.map(cpu_job, chunks))
    return sequential, threaded, processed


def main():
    import sys
    if "--cpu" in sys.argv:
        a, b, c = cpu_executors()
        print("sequential / thread / spawn process results agree:", a == b == c)
        return
    result = asyncio.run(run_jobs([.01, .02, .01, .02], capacity=1))
    print("completed:", result["completed"])
    print("peak active:", result["peak_active"])
    print("queue bounded:", result["peak_queued"] <= 1)
    print("active at end:", result["active_at_end"])


if __name__ == "__main__":
    main()
