"""Exact small distribution versus seeded sampling; counts stay explicit."""
import math
import numpy as np


def merge_means(groups):
    groups = list(groups)
    if any(type(count) is not int or count < 0 or not math.isfinite(mean)
           for mean, count in groups):
        raise ValueError("finite means and nonnegative integer counts required")
    count = sum(n for _, n in groups)
    if count == 0:
        raise ValueError("no effective samples")
    return math.fsum(mean * n for mean, n in groups) / count


def bernoulli_means(seed=106, probability=.25, batch=16, repetitions=2000):
    if not 0 <= probability <= 1 or batch < 1 or repetitions < 1:
        raise ValueError("invalid sampling parameters")
    random = np.random.default_rng(seed)
    draws = random.binomial(1, probability, size=(repetitions, batch))
    return draws.mean(axis=1)


def main():
    p, n = .25, 16
    values = bernoulli_means(probability=p, batch=n)
    print(f"population mean={p:.6f}; variance of independent mean={p*(1-p)/n:.6f}")
    print(f"sample mean={values.mean():.6f}; sample variance={values.var():.6f}")
    print(f"weighted mean={merge_means([(2., 7), (3., 5)]):.6f}; unweighted=2.500000")


if __name__ == "__main__":
    main()
