"""Configuration, independent mutable state and a checked scalar operation."""
from dataclasses import dataclass, field
from functools import wraps
from collections import defaultdict
import math


@dataclass
class Config:
    batch_size: int = 2
    tags: list[str] = field(default_factory=list)

    def __post_init__(self):
        if type(self.batch_size) is not int or self.batch_size < 1:
            raise ValueError("batch_size must be a positive integer")


def mean(values):
    values = list(values)
    if not values or not all(isinstance(x, (int, float)) and not isinstance(x, bool) and math.isfinite(x) for x in values):
        raise ValueError("expected nonempty finite numeric samples")
    return math.fsum(values) / len(values)


def checked(function):
    @wraps(function)
    def wrapper(*args, **kwargs):
        return function(*args, **kwargs)
    return wrapper


def grouped_sum(records):
    totals = defaultdict(float)
    for label, value in records:
        totals[label] += value
    return dict(totals)


def main():
    config = Config()
    other = Config()
    config.tags.append("cpu")
    print("independent config:", config.tags, other.tags)
    print("mean:", mean([0., 2., 4.]))
    print("totals:", grouped_sum([("a", 1), ("b", 2), ("a", 3)]))


if __name__ == "__main__":
    main()
