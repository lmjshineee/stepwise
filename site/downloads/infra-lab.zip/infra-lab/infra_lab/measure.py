"""CPU batch-call timings; no claims about request-level tail latency or GPUs."""
import math
import platform
import statistics
import time
import tracemalloc
import numpy as np


def loop_matmul(left, right):
    columns = list(zip(*right, strict=True))
    return [[math.fsum(a*b for a, b in zip(row, column, strict=True))
             for column in columns] for row in left]


def percentile(values, fraction):
    if not values or not 0 < fraction <= 1:
        raise ValueError("nonempty samples and fraction in (0,1] required")
    ordered = sorted(values)
    return ordered[math.ceil(fraction * len(ordered)) - 1]


def measure(function, warmup=2, repeats=7, inner=3):
    if type(warmup) is not int or warmup < 0 or any(type(n) is not int or n < 1 for n in (repeats, inner)):
        raise ValueError("invalid repeat counts")
    for _ in range(warmup):
        function()
    samples = []
    for _ in range(repeats):
        start = time.perf_counter_ns()
        for _ in range(inner):
            function()
        samples.append((time.perf_counter_ns() - start) / inner / 1e6)
    return {"samples_ms": samples, "median_ms": statistics.median(samples),
            "p95_ms": percentile(samples, .95), "p99_ms": percentile(samples, .99)}


def benchmark():
    random = np.random.default_rng(106)
    left, right = random.normal(size=(16, 12)), random.normal(size=(12, 8))
    rows, columns = left.tolist(), right.tolist()  # Conversion outside timing.
    reference = left @ right
    np.testing.assert_allclose(loop_matmul(rows, columns), reference, rtol=1e-12, atol=1e-12)
    cases = []
    for name, function in [("python_loop", lambda: loop_matmul(rows, columns)),
                           ("numpy_matmul", lambda: left @ right)]:
        timing = measure(function)
        tracemalloc.start()
        retained = function()
        _, python_peak = tracemalloc.get_traced_memory()
        tracemalloc.stop()
        cases.append({"name": name, **timing, "python_traced_peak_bytes": python_peak,
                      "rows_per_second_from_median": 16 / (timing["median_ms"] / 1000)})
        del retained
    return {"schema_version": 1, "scope": "CPU complete batch call; seven toy samples, not reliable serving P99",
            "environment": {"python": platform.python_version(), "numpy": np.__version__,
                            "system": platform.system(), "architecture": platform.machine()},
            "shapes": [[16, 12], [12, 8]], "dtype": "float64", "warmup": 2,
            "repeats": 7, "inner": 3, "cases": cases,
            "memory_scope": "tracemalloc tracing only; not a process RSS or device peak measurement"}


def main():
    import json
    print(json.dumps(benchmark(), indent=2))


if __name__ == "__main__":
    main()
