"""Observed floating point effects on the actual NumPy CPU dtype."""
import numpy as np
from .distributions import log_softmax


def stable_variance(values):
    count, mean, m2 = 0, 0., 0.
    for value in values:
        count += 1
        delta = float(value) - mean
        mean += delta / count
        m2 += delta * (float(value) - mean)
    if not count:
        raise ValueError("empty population")
    return m2 / count  # Population variance, not the n-1 sample estimator.


def main():
    large, small, negative = np.float32(1e8), np.float32(1), np.float32(-1e8)
    print("float32 sums:", float((large + small) + negative), float((large + negative) + small))
    values = [1e9 + 1, 1e9 + 2, 1e9 + 3]
    print(f"population variance (Welford): {stable_variance(values):.6f}")
    print("stable log probabilities finite:", bool(np.isfinite(log_softmax([1000., 1001., 999.])).all()))
    condition = np.linalg.cond(np.diag([1., .001]))
    print("diagonal 2-norm condition number:", condition)


if __name__ == "__main__":
    main()
