"""A diagonal convex quadratic with an optional Euclidean ball constraint."""
import math
import numpy as np


def project_ball(vector, radius):
    vector = np.asarray(vector, dtype=np.float64)
    if not math.isfinite(radius) or radius < 0 or not np.isfinite(vector).all():
        raise ValueError("finite vector and nonnegative finite radius required")
    norm = np.linalg.norm(vector)
    return vector.copy() if norm <= radius else vector * (radius / norm)


def descend(curvature=4., step=.2, iterations=12, radius=None):
    if not all(map(math.isfinite, (curvature, step))) or curvature < 1 or step <= 0 or type(iterations) is not int or iterations < 0:
        raise ValueError("invalid quadratic parameters")
    point = np.array([2., 1.])
    if radius is not None:
        point = project_ball(point, radius)
    path = [point.copy()]
    for _ in range(iterations):
        gradient = np.array([point[0], curvature * point[1]])
        point = point - step * gradient
        if radius is not None:
            point = project_ball(point, radius)
        path.append(point.copy())
    return np.array(path)


def main():
    path = descend()
    objective = lambda point: .5 * (point[0]**2 + 4 * point[1]**2)
    print(f"objective: {objective(path[0]):.6f} -> {objective(path[-1]):.6f}")
    print("projection of [3,4] onto unit ball:", project_ball([3., 4.], 1.).tolist())
    print("strict stable step interval for this quadratic: 0 < step < 0.5")


if __name__ == "__main__":
    main()
