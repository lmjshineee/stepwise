"""Lazily read rows and preserve the effective denominator across batches."""
from contextlib import closing
import json
import math
from pathlib import Path
import numpy as np


def read_rows(path):
    with Path(path).open(encoding="utf-8") as stream:
        for number, line in enumerate(stream, 1):
            row = json.loads(line)
            if not isinstance(row, list) or not all(type(x) in (int, float) and math.isfinite(x) for x in row):
                raise ValueError(f"line {number}: expected finite numeric list")
            yield row


def batches(rows, batch_size):
    if type(batch_size) is not int or batch_size < 1:
        raise ValueError("positive integer batch size required")
    pending = []
    for row in rows:
        pending.append(row)
        if len(pending) == batch_size:
            yield pending
            pending = []
    if pending:
        yield pending


def pad(rows):
    width = max(map(len, rows), default=0)
    values = np.zeros((len(rows), width), dtype=np.float64)
    mask = np.zeros_like(values, dtype=bool)
    for index, row in enumerate(rows):
        values[index, :len(row)] = row
        mask[index, :len(row)] = True
    return values, mask


def summarize(rows):
    values, mask = pad(rows)
    count = int(mask.sum())
    with np.errstate(over="raise", invalid="raise"):
        total = float(values[mask].sum())
    if not math.isfinite(total):
        raise ValueError("sum outside finite range")
    return total, count


def run(path, batch_size=2):
    total, count = 0., 0
    with closing(read_rows(path)) as rows:
        for batch in batches(rows, batch_size):
            subtotal, effective = summarize(batch)
            total += subtotal
            if not math.isfinite(total):
                raise ValueError("accumulated sum outside finite range")
            count += effective
    return {"sum": total, "count": count, "mean": total / count if count else None}


def main():
    print(run(Path(__file__).with_name("samples.jsonl")))


if __name__ == "__main__":
    main()
