"""Runnable, deliberately small CPU experiments. Importing does not run a job."""
