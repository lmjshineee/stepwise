"""A non-square linear layer, with shapes kept explicit."""
import numpy as np


def linear(x, weight, bias):
    x, weight, bias = (np.asarray(a, dtype=np.float64) for a in (x, weight, bias))
    if x.ndim != 2 or weight.ndim != 2 or bias.shape != (weight.shape[1],):
        raise ValueError("expected X[B,D], W[D,H], bias[H]")
    if x.shape[1] != weight.shape[0]:
        raise ValueError("inner dimensions differ")
    return x @ weight + bias


def main():
    x = np.array([[1., 2., 3.], [4., 5., 6.]])
    weight = np.array([[1., 0.], [0., 1.], [1., 1.]])
    result = linear(x, weight, [.5, -.5])
    print(result)
    batch, inputs = x.shape
    outputs = weight.shape[1]
    print("matmul FLOPs (2BDH):", 2 * batch * inputs * outputs)


if __name__ == "__main__":
    main()
