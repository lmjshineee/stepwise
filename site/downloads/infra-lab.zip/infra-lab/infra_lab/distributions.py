"""Log-space probabilities avoid an unnecessary exp-then-log round trip."""
import math
import numpy as np


def log_softmax(logits, temperature=1.):
    values = np.asarray(logits, dtype=np.float64)
    if values.ndim != 1 or not values.size or not np.isfinite(values).all():
        raise ValueError("expected nonempty finite logits")
    if not math.isfinite(temperature) or temperature <= 0:
        raise ValueError("positive finite temperature required")
    with np.errstate(over="raise", invalid="raise"):
        scaled = values / temperature
        shifted = scaled - scaled.max()
    return shifted - np.log(np.exp(shifted).sum())


def distribution(values):
    values = np.asarray(values, dtype=np.float64)
    if values.ndim != 1 or not values.size or not np.isfinite(values).all() or np.any(values < 0) or not np.isclose(values.sum(), 1., rtol=0., atol=1e-12):
        raise ValueError("expected nonnegative probabilities summing to one")
    return values


def entropy(probabilities):
    p = distribution(probabilities)
    positive = p > 0
    return float(-np.sum(p[positive] * np.log(p[positive])))


def kl_divergence(p, q):
    p, q = distribution(p), distribution(q)
    if p.shape != q.shape:
        raise ValueError("support dimensions differ")
    positive = p > 0
    if np.any(q[positive] == 0):
        return math.inf
    return float(np.sum(p[positive] * (np.log(p[positive]) - np.log(q[positive]))))


def main():
    logs = log_softmax([1000., 1001., 999.])
    probabilities = np.exp(logs)
    print("probabilities:", [round(x, 6) for x in probabilities.tolist()])
    print(f"target=1 cross entropy: {-logs[1]:.6f}")
    print(f"entropy: {entropy(probabilities):.6f}")
    print("KL([1,0] || [0,1]):", kl_divergence([1., 0.], [0., 1.]))


if __name__ == "__main__":
    main()
