"""Difference quotients and midpoint quadrature on known functions."""
import math


def difference(function, x, step):
    if not math.isfinite(step) or step <= 0:
        raise ValueError("step must be finite and positive")
    return (function(x + step) - function(x - step)) / (2 * step)


def midpoint(function, start, end, pieces):
    if type(pieces) is not int or pieces <= 0:
        raise ValueError("pieces must be a positive integer")
    if not all(map(math.isfinite, (start, end))):
        raise ValueError("finite interval required")
    width = (end - start) / pieces
    return width * math.fsum(function(start + (i + .5) * width) for i in range(pieces))


def main():
    print("derivative of x^2 at 2:", round(difference(lambda x: x*x, 2., .01), 6))
    for pieces in [4, 16]:
        value = midpoint(lambda x: x*x, 0., 2., pieces)
        print(f"midpoint n={pieces}: {value:.6f}; exact: {8/3:.6f}")


if __name__ == "__main__":
    main()
