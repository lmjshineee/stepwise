"""Actual CPU storage sharing, transpose strides and broadcast allocation."""
import numpy as np
import torch


def storage_case():
    original = np.arange(6, dtype=np.float32).reshape(2, 3)
    transposed = original.T
    independent = original.copy()
    transposed[0, 1] = 99
    tensor = torch.from_numpy(original)
    tensor[0, 0] = 7
    return original, transposed, independent, tensor


def broadcast_distance(points, centers):
    points = np.asarray(points, dtype=np.float64)
    centers = np.asarray(centers, dtype=np.float64)
    if points.ndim != 2 or centers.ndim != 2 or points.shape[1] != centers.shape[1]:
        raise ValueError("points[N,D] and centers[K,D] required")
    difference = points[:, None, :] - centers[None, :, :]
    return (difference * difference).sum(axis=-1)


def main():
    original, transposed, independent, tensor = storage_case()
    print("original:", original.tolist())
    print("transpose:", transposed.tolist())
    print("copy:", independent.tolist())
    print("element strides:", tuple(x // original.itemsize for x in original.strides), tuple(x // transposed.itemsize for x in transposed.strides))
    print("shared NumPy / PyTorch:", float(tensor[0, 0]), float(original[0, 0]))
    contiguous = tensor.T.contiguous()
    contiguous[0, 0] = -1
    print("contiguous copy leaves source:", float(tensor[0, 0]))
    print("distance shape:", broadcast_distance([[0, 0], [1, 1]], [[1, 0], [0, 1], [2, 2]]).shape)


if __name__ == "__main__":
    main()
