"""Manual gradients, finite differences and the actual PyTorch CPU reference."""
import numpy as np
import torch
from .calculus import difference


def scalar_graph(x, y):
    a = x * y
    b = a + x
    loss = b * b
    return loss, 2 * b * (y + 1), 2 * b * x


def linear_backward(x, weight, bias, target):
    prediction = x @ weight + bias
    upstream = prediction - target  # L = 1/2 sum((prediction - target)^2)
    loss = .5 * np.sum(upstream ** 2)
    return loss, upstream @ weight.T, x.T @ upstream, upstream.sum(axis=0)


def check_linear():
    x = np.array([[1., 2.], [3., 4.]])
    weight = np.array([[2., -1.], [1., 3.]])
    bias = np.array([.5, -.5])
    target = np.array([[1., 0.], [0., 1.]])
    loss, dx, dw, db = linear_backward(x, weight, bias, target)
    tx, tw, tb = (torch.tensor(a, dtype=torch.float64, requires_grad=True)
                  for a in (x, weight, bias))
    expected = .5 * ((tx @ tw + tb - torch.tensor(target)) ** 2).sum()
    expected.backward()
    for actual, tensor in [(dx, tx), (dw, tw), (db, tb)]:
        np.testing.assert_allclose(actual, tensor.grad.numpy(), rtol=1e-12, atol=1e-12)
    numerical = np.empty_like(weight)
    for index in np.ndindex(weight.shape):
        def at(value):
            changed = weight.copy()
            changed[index] = value
            return linear_backward(x, changed, bias, target)[0]
        numerical[index] = difference(at, weight[index], 1e-5)
    np.testing.assert_allclose(dw, numerical, rtol=1e-8, atol=1e-8)
    return float(loss), dx, dw, db


def mode_checks():
    x = torch.tensor(2., requires_grad=True)
    (x*x).backward()
    (x*x).backward()  # A fresh forward graph, the same leaf buffer.
    accumulated = x.grad.item()
    x.grad = None
    with torch.no_grad():
        detached = x*x
        with torch.enable_grad():
            recorded = x*x
    dropout = torch.nn.Dropout().eval()
    eval_output = dropout(x)
    with torch.inference_mode():
        inference = torch.ones(1)
    try:
        inference.requires_grad_()
    except RuntimeError:
        inference_rejected = True
    else:
        inference_rejected = False
    return accumulated, detached.requires_grad, recorded.requires_grad, eval_output.requires_grad, inference_rejected


def main():
    loss, dx, dy = scalar_graph(2., 3.)
    print("shared graph:", loss, dx, dy)
    check_linear()
    print("manual / autograd / finite difference: agree")
    print("buffer, no_grad, enable_grad, eval, inference rejection:", mode_checks())


if __name__ == "__main__":
    main()
