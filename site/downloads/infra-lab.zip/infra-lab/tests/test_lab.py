import asyncio
from contextlib import closing
import io
import json
import math
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import numpy as np
import torch
from infra_lab import linear, low_rank, calculus, backward, probability, distributions, convex, numerics, basics, tensors, pipeline, concurrency, measure


class Mathematics(unittest.TestCase):
    def test_linear_non_square_and_bias(self):
        actual = linear.linear([[1, 2, 3], [4, 5, 6]], [[1, 0], [0, 1], [1, 1]], [.5, -.5])
        np.testing.assert_array_equal(actual, [[4.5, 4.5], [10.5, 10.5]])
        self.assertEqual(linear.linear(np.zeros((0, 3)), np.zeros((3, 2)), [0, 0]).shape, (0, 2))

    def test_linear_rejects_wrong_broadcast_and_inner_dimension(self):
        for args in [([[1, 2]], [[1], [2]], [[0]]), ([[1]], [[1], [2]], [0])]:
            with self.assertRaises(ValueError):
                linear.linear(*args)

    def test_svd_zero_full_and_truncated(self):
        matrix = np.diag([4., 1.])
        for rank, expected_error in [(0, math.sqrt(17)), (1, 1.), (2, 0.)]:
            result, singular = low_rank.approximate(matrix, rank)
            self.assertAlmostEqual(np.linalg.norm(result - matrix), expected_error)
        np.testing.assert_array_equal(low_rank.approximate(np.zeros((2, 3)), 1)[0], np.zeros((2, 3)))
        with self.assertRaises(ValueError):
            low_rank.approximate(matrix, 3)

    def test_calculus_analytic_answers(self):
        self.assertAlmostEqual(calculus.difference(lambda x: x*x, 2, .01), 4)
        self.assertAlmostEqual(calculus.midpoint(lambda x: x*x, 0, 2, 4), 2.625)
        self.assertAlmostEqual(calculus.midpoint(lambda x: x*x, 2, 0, 4), -2.625)
        self.assertAlmostEqual(calculus.midpoint(lambda x: 3*x+1, 0, 2, 7), 8)
        for h in [0, -1, math.inf]:
            with self.assertRaises(ValueError):
                calculus.difference(math.sin, 1, h)

    def test_shared_graph_independent_finite_difference(self):
        loss, dx, dy = backward.scalar_graph(2, 3)
        self.assertEqual((loss, dx, dy), (64, 64, 32))
        self.assertAlmostEqual(dx, calculus.difference(lambda x: backward.scalar_graph(x, 3)[0], 2, 1e-5), places=6)
        self.assertAlmostEqual(dy, calculus.difference(lambda y: backward.scalar_graph(2, y)[0], 3, 1e-5), places=6)

    def test_linear_gradients_against_torch_and_finite_difference(self):
        loss, dx, dw, db = backward.check_linear()
        self.assertEqual(dx.shape, (2, 2))
        self.assertEqual(dw.shape, (2, 2))
        self.assertEqual(db.shape, (2,))
        self.assertGreater(loss, 0)

    def test_actual_gradient_buffer_and_modes(self):
        self.assertEqual(backward.mode_checks(), (8., False, True, True, True))
        x = torch.tensor(2., requires_grad=True)
        self.assertEqual(torch.autograd.grad(x*x+x, x)[0].item(), 5)
        x = torch.tensor([1., 2.], requires_grad=True)
        y = x*x
        with self.assertRaises(RuntimeError):
            y.backward()
        torch.testing.assert_close(torch.autograd.grad(y, x, grad_outputs=torch.tensor([3., 4.]))[0], torch.tensor([6., 16.]))

    def test_weighted_means_keep_denominator(self):
        self.assertAlmostEqual(probability.merge_means([(2, 7), (3, 5)]), 29/12)
        self.assertEqual(probability.merge_means([(99, 0), (4, 2)]), 4)
        with self.assertRaises(ValueError):
            probability.merge_means([(0, 0)])
        with self.assertRaises(ValueError):
            probability.merge_means([(3, -1)])

    def test_seed_and_deterministic_probability_boundaries(self):
        np.testing.assert_array_equal(probability.bernoulli_means(), probability.bernoulli_means())
        np.testing.assert_array_equal(probability.bernoulli_means(probability=0), 0)
        np.testing.assert_array_equal(probability.bernoulli_means(probability=1), 1)
        values = probability.bernoulli_means(repetitions=20000)
        self.assertLess(abs(values.mean() - .25), .003)
        self.assertLess(abs(values.var() - .25*.75/16), .0005)

    def test_softmax_translation_log_space_and_invalid_inputs(self):
        a = distributions.log_softmax([1, 2, 0])
        b = distributions.log_softmax([1000, 1001, 999])
        np.testing.assert_allclose(a, b, atol=1e-12)
        self.assertAlmostEqual(np.exp(a).sum(), 1)
        self.assertAlmostEqual(-a[1], .4076059644443804)
        self.assertTrue(np.isfinite(distributions.log_softmax([-1000, 1000])).all())
        for bad in [[], [math.inf], [math.nan]]:
            with self.assertRaises(ValueError):
                distributions.log_softmax(bad)
        for temperature in [0, -1, math.inf]:
            with self.assertRaises(ValueError):
                distributions.log_softmax([1, 2], temperature)

    def test_kl_support_and_direction(self):
        self.assertEqual(distributions.entropy([1, 0]), 0)
        self.assertAlmostEqual(distributions.entropy([.5, .5]), math.log(2))
        self.assertEqual(distributions.kl_divergence([1, 0], [1, 0]), 0)
        self.assertEqual(distributions.kl_divergence([1, 0], [0, 1]), math.inf)
        self.assertNotAlmostEqual(distributions.kl_divergence([.8, .2], [.5, .5]), distributions.kl_divergence([.5, .5], [.8, .2]))
        with self.assertRaises(ValueError):
            distributions.entropy([.1, .1])

    def test_convex_known_quadratic_and_projection(self):
        np.testing.assert_allclose(convex.project_ball([3, 4], 1), [.6, .8])
        np.testing.assert_array_equal(convex.project_ball([0, 0], 0), [0, 0])
        path = convex.descend()
        losses = .5*(path[:, 0]**2+4*path[:, 1]**2)
        self.assertTrue(np.all(np.diff(losses) < 0))
        unstable = convex.descend(step=.6)
        self.assertGreater(np.linalg.norm(unstable[-1]), np.linalg.norm(unstable[0]))
        constrained = convex.descend(step=.6, radius=1.)
        self.assertTrue(np.all(np.linalg.norm(constrained, axis=1) <= 1+1e-12))

    def test_real_float32_and_stable_variance(self):
        a, b, c = np.float32(1e8), np.float32(1), np.float32(-1e8)
        self.assertEqual(float((a+b)+c), 0.)
        self.assertEqual(float((a+c)+b), 1.)
        self.assertAlmostEqual(numerics.stable_variance([1e9+1, 1e9+2, 1e9+3]), 2/3)
        with self.assertRaises(ValueError):
            numerics.stable_variance([])


class PythonContracts(unittest.TestCase):
    def test_configuration_and_mean_contract(self):
        a, b = basics.Config(), basics.Config()
        a.tags.append('cpu')
        self.assertEqual(b.tags, [])
        self.assertEqual(basics.mean([0, 2, 4]), 2)
        self.assertEqual(basics.mean([7]), 7)
        for values in [[], [math.nan], [True], ['2']]:
            with self.assertRaises(ValueError):
                basics.mean(values)
        for size in [0, -1, True, 1.5]:
            with self.assertRaises(ValueError):
                basics.Config(size)

    def test_wrapper_metadata_result_and_error(self):
        wrapped = basics.checked(basics.mean)
        self.assertEqual(wrapped.__name__, 'mean')
        self.assertEqual(wrapped([1, 3]), 2)
        with self.assertRaises(ValueError):
            wrapped([])

    def test_actual_numpy_torch_sharing(self):
        original, transpose, independent, tensor = tensors.storage_case()
        self.assertEqual(original[1, 0], 99)
        self.assertEqual(original[0, 0], 7)
        self.assertEqual(independent[1, 0], 3)
        self.assertEqual(independent[0, 0], 0)
        self.assertTrue(np.shares_memory(original, transpose))
        self.assertFalse(np.shares_memory(original, independent))
        self.assertFalse(tensor.T.is_contiguous())
        self.assertEqual(tensor.T.stride(), (1, 3))
        copied = tensor.T.contiguous()
        copied[0, 0] = -2
        self.assertEqual(tensor[0, 0], 7)

    def test_broadcast_against_nested_reference(self):
        points, centers = [[0, 0], [1, 1]], [[1, 0], [0, 1], [2, 2]]
        expected = [[sum((a-b)**2 for a, b in zip(p, c)) for c in centers] for p in points]
        np.testing.assert_array_equal(tensors.broadcast_distance(points, centers), expected)

    def test_batch_masks_keep_valid_zero_and_empty_input(self):
        values, mask = pipeline.pad([[0, 2], [4]])
        np.testing.assert_array_equal(mask, [[True, True], [True, False]])
        self.assertEqual(pipeline.summarize([[0, 2], [4]]), (6., 3))
        self.assertEqual(pipeline.summarize([[], []]), (0., 0))
        self.assertEqual(list(pipeline.batches([], 2)), [])
        actual = list(pipeline.batches([[1], [2], [3]], 2))
        self.assertEqual(actual, [[[1], [2]], [[3]]])
        self.assertIsNot(actual[0], actual[1])
        with self.assertRaises(ValueError):
            list(pipeline.batches([], 0))

    def test_jsonl_pipeline_bad_line_and_empty_file(self):
        with tempfile.TemporaryDirectory() as temp:
            p = Path(temp)/'data.jsonl'
            p.write_text('[1,2,3]\n[4]\n[5,6]\n')
            self.assertEqual(pipeline.run(p), {'sum':21., 'count':6, 'mean':3.5})
            p.write_text('')
            self.assertIsNone(pipeline.run(p)['mean'])
            p.write_text('[1]\n["bad"]\n')
            with self.assertRaisesRegex(ValueError, 'line 2'):
                pipeline.run(p)
            p.write_text('[1e308]\n[1e308]\n')
            with self.assertRaisesRegex(ValueError, 'accumulated sum'):
                pipeline.run(p, batch_size=1)

    def test_early_close_releases_stream(self):
        stream = io.StringIO('[1]\n[2]\n')
        with patch.object(Path, 'open', return_value=stream):
            with closing(pipeline.read_rows('fixture')) as rows:
                self.assertEqual(next(rows), [1])
            self.assertTrue(stream.closed)

    def test_grouping_scattered_labels(self):
        self.assertEqual(basics.grouped_sum([('a', 1), ('b', 2), ('a', 3)]), {'a':4., 'b':2.})

    def test_measurement_reference_and_sample_contract(self):
        expected = [[19., 22.], [43., 50.]]
        self.assertEqual(measure.loop_matmul([[1.,2.],[3.,4.]], [[5.,6.],[7.,8.]]), expected)
        self.assertEqual(measure.percentile([1, 2, 3, 100], .95), 100)
        report = measure.benchmark()
        self.assertEqual(len(report['cases']), 2)
        for case in report['cases']:
            self.assertEqual(len(case['samples_ms']), 7)
            self.assertGreater(case['median_ms'], 0)
            self.assertTrue(all(math.isfinite(x) and x > 0 for x in case['samples_ms']))


class AsyncContracts(unittest.IsolatedAsyncioTestCase):
    async def test_bounded_completion_without_duplicates(self):
        result = await concurrency.run_jobs([0]*9, concurrency=3, capacity=1)
        self.assertEqual(result['completed'], list(range(9)))
        self.assertLessEqual(result['peak_active'], 3)
        self.assertLessEqual(result['peak_queued'], 1)
        self.assertEqual(result['active_at_end'], 0)

    async def test_timeout_cleans_children(self):
        before = set(asyncio.all_tasks())
        with self.assertRaises(TimeoutError):
            await concurrency.run_jobs([10]*8, timeout=.01, capacity=1)
        await asyncio.sleep(0)
        self.assertEqual(set(asyncio.all_tasks()), before)

    async def test_failure_cancels_other_workers(self):
        before = set(asyncio.all_tasks())
        with self.assertRaises(ExceptionGroup) as error:
            await concurrency.run_jobs([0, 10, 10], fail_at=0, capacity=1)
        self.assertTrue(any(isinstance(e, RuntimeError) for e in error.exception.exceptions))
        await asyncio.sleep(0)
        self.assertEqual(set(asyncio.all_tasks()), before)

    async def test_empty_and_invalid(self):
        self.assertEqual((await concurrency.run_jobs([]))['completed'], [])
        for values, kwargs in [([0], {'capacity':0}), ([-1], {}), ([0], {'timeout':0})]:
            with self.assertRaises(ValueError):
                await concurrency.run_jobs(values, **kwargs)


if __name__ == '__main__':
    unittest.main()
